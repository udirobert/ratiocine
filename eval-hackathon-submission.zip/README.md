# Morpheme Induction Eval — micro1 Eval Hackathon submission

See `eval-hackathon/README.md` for the full methodology and
`eval-hackathon/REPORT.md` for the eval report (limitation statement,
results, failure analysis, provenance).

Quick start:

```bash
python3 eval-hackathon/run_eval.py --model <model-id> --provider neon \
    --puzzles-file eval-hackathon/data/puzzles_obf_1.json --trial 1
python3 eval-hackathon/aggregate.py --markdown
python3 eval-hackathon/regrade.py   # re-grade stored raws, no API cost
```

Python 3.10+, standard library only. Provider keys via env vars — see
`.env.example`. Stored generations in `eval-hackathon/results/` let you
re-grade every reported number without any API access.
